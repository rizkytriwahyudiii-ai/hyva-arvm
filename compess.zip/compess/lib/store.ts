import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { supabase } from '@/lib/supabaseClient';

interface CartItem {
  id: string;
  name: string;
  price: number;
  image_url: string;
  quantity: number;
}

interface CartState {
  cart: CartItem[];
  isCartOpen: boolean;
  setCartOpen: (status: boolean) => void;
  loadCart: () => Promise<void>;
  addToCart: (product: any) => Promise<void>;
  removeFromCart: (productId: string) => Promise<void>;
  updateQuantity: (productId: string, delta: number) => Promise<void>;
}

export const useCartStore = create<CartState>()(
  persist(
    (set, get) => ({
      cart: [],
      isCartOpen: false,
      setCartOpen: (status) => set({ isCartOpen: status }),

      // Load data dari Supabase
      loadCart: async () => {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) return;

        const { data } = await supabase
          .from('cart_items')
          .select('*')
          .eq('user_id', user.id);

        if (data) set({ cart: data });
      },

      addToCart: async (product) => {
        set((state) => {
          const existingItem = state.cart.find((item) => item.id === product.id);
          const newCart = existingItem
            ? state.cart.map((item) => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item)
            : [...state.cart, { ...product, quantity: 1 }];
          return { cart: newCart };
        });

        const { data: { user } } = await supabase.auth.getUser();
        if (user) {
          const item = get().cart.find(i => i.id === product.id);
          await supabase.from('cart_items').upsert({
            user_id: user.id,
            product_id: product.id,
            name: product.name,
            price: product.price,
            image_url: product.image_url,
            quantity: item?.quantity || 1
          });
        }
      },

      removeFromCart: async (productId) => {
        set((state) => ({ cart: state.cart.filter((item) => item.id !== productId) }));
        
        const { data: { user } } = await supabase.auth.getUser();
        if (user) {
          await supabase.from('cart_items').delete().eq('user_id', user.id).eq('product_id', productId);
        }
      },

      updateQuantity: async (productId, delta) => {
        set((state) => ({
          cart: state.cart.map((item) =>
            item.id === productId ? { ...item, quantity: Math.max(1, item.quantity + delta) } : item
          ),
        }));

        const { data: { user } } = await supabase.auth.getUser();
        if (user) {
          const item = get().cart.find(i => i.id === productId);
          if (item) {
            await supabase.from('cart_items').update({ quantity: item.quantity }).eq('user_id', user.id).eq('product_id', productId);
          }
        }
      },
    }),
    { name: 'cart-storage' }
  )
);