'use client';

import { useState, useEffect, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import { supabase } from '@/lib/supabaseClient';

import HeroSection from '@/components/HeroSection';
import ProductSection from '@/components/ProductSection';

// Tambahan section premium
import AboutBrand from '@/components/AboutBrand';
import FragranceNotes from '@/components/FragranceNotes';
import TestimonialSection from '@/components/TestimonialSection';
import Footer from '@/components/Footer';

function ProductList() {
  const searchParams = useSearchParams();
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const category = searchParams.get('category') || '';
  const query = searchParams.get('q') || '';

  useEffect(() => {
    async function fetchProducts() {
      setLoading(true);

      try {
        let dbQuery = supabase.from('products').select('*');

        if (category && category !== 'Semua') {
          dbQuery = dbQuery.eq('category', category.toLowerCase());
        }

        if (query) {
          dbQuery = dbQuery.or(
            `name.ilike.%${query}%,description.ilike.%${query}%`
          );
        }

        const { data, error } = await dbQuery;

        if (error) throw error;

        setProducts(data || []);
      } catch (err) {
        setProducts([]);
      } finally {
        setLoading(false);
      }
    }

    fetchProducts();
  }, [category, query]);

  if (loading) {
    return (
      <div className="text-center text-gray-400 py-20">
        Memuat koleksi...
      </div>
    );
  }

  // Halaman hasil pencarian / filter kategori
  if (query || category) {
    return (
      <ProductSection
        title={query ? `Hasil: ${query}` : `Koleksi ${category}`}
        products={products}
      />
    );
  }

  // Homepage utama
  return (
    <>
      <ProductSection
        title="Signature Collection"
        products={products.slice(0, 4)}
        categoryFilter="signature"
      />

      <ProductSection
        title="For Her"
        products={products.filter(
          (p) => p.category?.toLowerCase() === 'wanita'
        )}
        categoryFilter="wanita"
      />

      <ProductSection
        title="For Him"
        products={products.filter(
          (p) => p.category?.toLowerCase() === 'pria'
        )}
        categoryFilter="pria"
      />

      <ProductSection
        title="Unisex Collection"
        products={products.filter(
          (p) => p.category?.toLowerCase() === 'unisex'
        )}
        categoryFilter="unisex"
      />
    </>
  );
}

export default function HomePage() {
  return (
    <>
      <HeroSection />

      <Suspense
        fallback={
          <div className="text-center py-20">
            Memuat konten...
          </div>
        }
      >
        <ProductList />
      </Suspense>

      {/* Section Premium */}
      <AboutBrand />

      <FragranceNotes />

      <TestimonialSection />

      <Footer />
    </>
  );
}