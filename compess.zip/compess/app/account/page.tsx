'use client';
import { useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabaseClient"; // Import diperbaiki
import toast from "react-hot-toast";

export default function AccountPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  
  const [oldPassword, setOldPassword] = useState("");
  const [newEmail, setNewEmail] = useState("");
  const [newPassword, setNewPassword] = useState("");

  const handleUpdateAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user || !user.email) throw new Error("User tidak ditemukan");

      // 1. Verifikasi Password Lama
      const { error: signInError } = await supabase.auth.signInWithPassword({
        email: user.email,
        password: oldPassword,
      });

      if (signInError) throw new Error("Password lama salah");

      // 2. Update Email dan/atau Password
      const { error: updateError } = await supabase.auth.updateUser({
        email: newEmail || undefined,
        password: newPassword || undefined,
      });

      if (updateError) throw updateError;

      toast.success("Akun berhasil diperbarui!");
      setOldPassword("");
      setNewEmail("");
      setNewPassword("");
    } catch (error: any) {
      toast.error(error.message || "Terjadi kesalahan");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto mt-32 p-6">
      <button onClick={() => router.back()} className="text-[11px] font-bold text-gray-500 mb-6 hover:text-black">← KEMBALI</button>
      
      <h1 className="text-2xl font-bold mb-6">PENGATURAN AKUN</h1>
      
      <form onSubmit={handleUpdateAccount} className="flex flex-col gap-4">
        <div>
          <label className="text-[10px] font-bold text-red-500">PASSWORD LAMA (WAJIB)</label>
          <input 
            type="password" 
            value={oldPassword} 
            onChange={(e) => setOldPassword(e.target.value)} 
            required 
            className="w-full p-3 border rounded-lg text-sm mt-1" 
            placeholder="Masukkan password lama untuk konfirmasi" 
          />
        </div>

        <hr className="my-2" />

        <div>
          <label className="text-[10px] font-bold text-gray-400">EMAIL BARU</label>
          <input 
            type="email" 
            value={newEmail} 
            onChange={(e) => setNewEmail(e.target.value)} 
            className="w-full p-3 border rounded-lg text-sm mt-1" 
            placeholder="Masukkan email baru jika ingin mengganti"
          />
        </div>
        
        <div>
          <label className="text-[10px] font-bold text-gray-400">PASSWORD BARU</label>
          <input 
            type="password" 
            value={newPassword} 
            onChange={(e) => setNewPassword(e.target.value)} 
            className="w-full p-3 border rounded-lg text-sm mt-1" 
            placeholder="Kosongkan jika tidak ingin diubah" 
          />
        </div>

        <button 
          type="submit" 
          disabled={loading} 
          className="w-full bg-black text-white py-3 rounded-lg font-bold text-sm hover:bg-gray-800 transition-all mt-2 disabled:opacity-50"
        >
          {loading ? "Memproses..." : "SIMPAN PERUBAHAN"}
        </button>
      </form>
    </div>
  );
}