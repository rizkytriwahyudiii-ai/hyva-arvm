import type { Metadata } from "next";
import { Playfair_Display, Inter } from "next/font/google";
import Navbar from "@/components/navbar/navbar";
import "./globals.css";
import { Toaster } from 'react-hot-toast'; // Pastikan sudah di-install

const playfair = Playfair_Display({ variable: "--font-serif", subsets: ["latin"] });
const inter = Inter({ variable: "--font-sans", subsets: ["latin"] });

export const metadata: Metadata = {
  title: "Hyva Arvm | Luxury Fragrance",
  description: "Temukan koleksi parfum premium Hyva Arvm",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="id" className={`${playfair.variable} ${inter.variable} h-full antialiased`}>
      <body className="min-h-full flex flex-col bg-white text-gray-900 font-sans">
        {/* Tambahkan Toaster di sini untuk menangani notifikasi global */}
        <Toaster 
  position="top-center"
  toastOptions={{
    style: {
      background: '#000',
      color: '#fff',
      borderRadius: '8px',
      fontSize: '12px',
      padding: '12px 20px',
    },
  }}
/>
        
        <Navbar />

        {/* pt-20 sudah tepat untuk offset fixed navbar */}
        <main className="flex-grow w-full pt-20"> 
          {children}
        </main>

        <footer className="border-t border-gray-200 py-12 text-center bg-white text-gray-500">
          <p className="text-[10px] uppercase tracking-[0.3em]">
            © 2026 Hyva Arvm. All Rights Reserved.
          </p>
        </footer>
      </body>
    </html>
  );
}