'use client';
import { useState, useEffect } from 'react';
import { LayoutDashboard, Trash2, Edit2, Save, PlusCircle } from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';

const STORAGE_URL = `${process.env.NEXT_PUBLIC_SUPABASE_URL}/storage/v1/object/public/produk-parfum/`;

export default function AdminPage() {
  const [activeTab, setActiveTab] = useState('catalog');
  const [products, setProducts] = useState<any[]>([]);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState({ name: '', category: 'Wanita', price: 0, image_filename: '', description: '' });
  const [imageFile, setImageFile] = useState<File | null>(null);

  const fetchProducts = async () => {
    const { data, error } = await supabase.from('products').select('*');
    if (!error) setProducts(data || []);
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  const saveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    let filename = formData.image_filename;

    try {
      // 1. Proses Upload ke Storage jika ada file baru
      if (imageFile) {
        // Hapus file lama jika sedang mengedit
        if (editingId && formData.image_filename) {
          await supabase.storage.from('produk-parfum').remove([formData.image_filename]);
        }

        const fileExt = imageFile.name.split('.').pop();
        const newFileName = `${Date.now()}.${fileExt}`;
        const { error: uploadError } = await supabase.storage
          .from('produk-parfum')
          .upload(newFileName, imageFile);

        if (uploadError) throw uploadError;
        filename = newFileName;
      }

      const dataToSave = { ...formData, image_filename: filename };

      // 2. Simpan ke Database
      if (editingId) {
        const { error } = await supabase.from('products').update(dataToSave).eq('id', editingId);
        if (error) throw error;
      } else {
        const { error } = await supabase.from('products').insert([dataToSave]);
        if (error) throw error;
      }

      // 3. Reset State & Refresh
      setEditingId(null);
      setImageFile(null);
      setFormData({ name: '', category: 'Wanita', price: 0, image_filename: '', description: '' });
      fetchProducts();
      alert("Berhasil disimpan!");
    } catch (error: any) {
      alert("Gagal: " + error.message);
    }
  };

  const startEdit = (product: any) => {
    setEditingId(product.id);
    setFormData(product);
    setImageFile(null);
    window.scrollTo({ top: 0, behavior: 'smooth' }); // Scroll ke atas agar user tahu form edit terbuka
  };

  const deleteProduct = async (id: number, filename: string) => {
    if (!confirm('Yakin ingin menghapus produk ini?')) return;
    
    try {
      // Hapus dari Storage
      await supabase.storage.from('produk-parfum').remove([filename]);
      // Hapus dari Database
      const { error } = await supabase.from('products').delete().eq('id', id);
      if (error) throw error;
      fetchProducts();
    } catch (error: any) {
      alert("Gagal menghapus: " + error.message);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 p-8 font-sans text-slate-900">
      <div className="max-w-[1400px] mx-auto bg-white p-8 rounded-2xl shadow-sm border border-slate-100">
        <div className="flex justify-between items-center border-b-2 border-amber-700 pb-6 mb-8">
          <h2 className="text-xl font-bold flex items-center gap-3">
            <LayoutDashboard className="text-amber-700" /> Hyva Arvm Management Control Center
          </h2>
        </div>

        {activeTab === 'catalog' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="bg-slate-50 p-6 rounded-xl border h-fit">
              <h3 className="font-bold mb-6 flex items-center gap-2 border-l-4 border-amber-700 pl-2">
                {editingId ? <Edit2 size={18}/> : <PlusCircle size={18} />} 
                {editingId ? 'Edit Produk' : 'Tambah Produk Baru'}
              </h3>
              <form onSubmit={saveProduct} className="space-y-4">
                <input required className="w-full p-3 border rounded-lg text-sm" placeholder="Nama Varian Parfum" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} />
                <div className="grid grid-cols-2 gap-2">
                  <select className="p-3 border rounded-lg text-sm" value={formData.category} onChange={e => setFormData({...formData, category: e.target.value})}>
                    <option>Wanita</option><option>Pria</option><option>Unisex</option>
                  </select>
                  <input type="number" required className="p-3 border rounded-lg text-sm" placeholder="Harga" value={formData.price} onChange={e => setFormData({...formData, price: Number(e.target.value)})} />
                </div>
                
                <div className="space-y-1">
                    <label className="text-xs font-semibold text-slate-500">Upload Foto Produk:</label>
                    <input type="file" accept="image/*" onChange={(e) => e.target.files && setImageFile(e.target.files[0])} className="w-full p-2 border rounded-lg text-sm" />
                </div>

                <textarea className="w-full p-3 border rounded-lg text-sm h-24" placeholder="Deskripsi Produk" value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} />
                <div className="flex gap-2">
                    <button type="submit" className="flex-1 bg-slate-900 text-white py-3 rounded-lg font-bold hover:bg-slate-800">
                        <Save size={16} className="inline mr-2" /> {editingId ? 'Update Varian' : 'Simpan Varian'}
                    </button>
                    {editingId && <button type="button" onClick={() => {setEditingId(null); setFormData({ name: '', category: 'Wanita', price: 0, image_filename: '', description: '' });}} className="px-4 bg-gray-200 rounded-lg">Batal</button>}
                </div>
              </form>
            </div>

            <div className="lg:col-span-2">
              <div className="border rounded-xl overflow-hidden">
                <table className="w-full text-sm">
                  <thead className="bg-slate-900 text-white">
                    <tr><th className="p-4">FOTO</th><th className="p-4">NAMA</th><th className="p-4">HARGA</th><th className="p-4">AKSI</th></tr>
                  </thead>
                  <tbody>
                    {products.map((p: any) => (
                      <tr key={p.id}>
                        <td className="p-4"><img src={`${STORAGE_URL}${p.image_filename}`} className="w-12 h-12 rounded object-cover" alt={p.name} onError={(e) => (e.currentTarget.src = '/placeholder.jpg')} /></td>
                        <td className="p-4 font-semibold">{p.name}</td>
                        <td className="p-4 text-amber-700 font-bold">Rp {p.price?.toLocaleString()}</td>
                        <td className="p-4 flex gap-2">
                          <button onClick={() => startEdit(p)} className="bg-amber-600 text-white p-2 rounded"><Edit2 size={14}/></button>
                          <button onClick={() => deleteProduct(p.id, p.image_filename)} className="bg-red-500 text-white p-2 rounded"><Trash2 size={14}/></button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}