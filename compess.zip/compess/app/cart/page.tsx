export default function Page() { return <div className="p-20">Keranjang Belanja</div> } 
