'use client';
import { useState, useEffect, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import { supabase } from '@/lib/supabaseClient';
import ProductCard from '@/components/ProductCard';
import HeroSection from '@/components/HeroSection';


function SearchResults() {
  const searchParams = useSearchParams();
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  
  const query = searchParams.get('q') || "";

        useEffect(() => {
            async function fetchSearch() {
              if (!query) {
                setLoading(false);
                return;
              }
              
              setLoading(true);
              
              // PECAH QUERY MENJADI KATA-KATA KUNCI
              // Contoh: "Aroma Floral" -> ["Aroma", "Floral"]
              const keywords = query.split(" ").filter(k => k.length > 2); 

              let dbQuery = supabase.from('products').select('*');

              if (keywords.length > 0) {
                // Jika ada banyak kata, kita gunakan .or untuk setiap kata
                // Ini mencari apakah salah satu kata kunci ada di name ATAU description
                const filterString = keywords.map(k => 
                  `name.ilike.%${k}%,description.ilike.%${k}%`
                ).join(',');
                
                dbQuery = dbQuery.or(filterString);
              }

              const { data, error } = await dbQuery;

              if (error) {
                console.error('Error fetching search results:', error);
              } else {
                // Hapus duplikat produk (jika satu produk cocok di banyak kata kunci)
                const uniqueProducts = Array.from(new Set(data?.map(p => p.id)))
                  .map(id => data?.find(p => p.id === id));
                setProducts(uniqueProducts || []);
              }
              
              setLoading(false);
            }
            
            fetchSearch();
          }, [query]);

  return (
    <div className="pt-32 max-w-7xl mx-auto px-6 mb-20">
      <h1 className="text-sm uppercase tracking-[0.4em] text-center mb-16 text-gray-400">
        Hasil pencarian untuk: "{query}"
      </h1>

      {loading ? (
        <div className="text-center text-gray-400">Mencari...</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {products.length > 0 ? (
            products.map((product: any) => <ProductCard key={product.id} product={product} />)
          ) : (
            <p className="col-span-full text-center text-gray-500">Produk tidak ditemukan.</p>
          )}
        </div>
      )}
    </div>
  );
}

export default function SearchPage() {
  return (
    <>
      <HeroSection />
    <Suspense fallback={<div className="pt-32 text-center">Loading...</div>}>
      <SearchResults />
    </Suspense>
    </>
  );
}