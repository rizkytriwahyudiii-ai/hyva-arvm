export default function Page() { return <div className="p-20">Halaman Pendaftaran</div> } 
