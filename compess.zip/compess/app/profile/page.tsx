'use client';
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation"; // Import useRouter
import { supabase } from "../../lib/supabaseClient";

export default function ProfilePage() {
  const router = useRouter(); // Inisialisasi router
  const [loading, setLoading] = useState(true);
  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (user) {
      const { data } = await supabase.from("profiles").select("*").eq("id", user.id).single();
      if (data) {
        setFullName(data.full_name);
        setPhone(data.phone);
        setAddress(data.address);
      }
    }
    setLoading(false);
  };

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const { data: { user } } = await supabase.auth.getUser();
    
    if (user) {
      const { error } = await supabase.from("profiles").update({
        full_name: fullName,
        phone: phone,
        address: address
      }).eq("id", user.id);

      if (error) alert("Gagal update: " + error.message);
      else alert("Profil berhasil diperbarui!");
    }
    setLoading(false);
  };

  if (loading) return <div className="p-20 text-center">Loading...</div>;

  return (
    <div className="max-w-md mx-auto mt-32 p-6">
      {/* Tombol Kembali */}
      <button 
        onClick={() => router.back()} 
        className="text-[11px] font-bold text-gray-500 hover:text-black mb-6 flex items-center gap-1"
      >
        ← KEMBALI
      </button>

      <h1 className="text-2xl font-bold mb-6">UBAH PROFIL</h1>
      
      <form onSubmit={handleUpdate} className="flex flex-col gap-4">
        <input value={fullName} onChange={(e) => setFullName(e.target.value)} className="w-full p-3 border rounded-lg text-sm" placeholder="Nama Lengkap" />
        <input value={phone} onChange={(e) => setPhone(e.target.value)} className="w-full p-3 border rounded-lg text-sm" placeholder="Nomor WhatsApp" />
        <textarea value={address} onChange={(e) => setAddress(e.target.value)} className="w-full p-3 border rounded-lg text-sm" placeholder="Alamat Lengkap" />
        <button type="submit" className="bg-black text-white py-3 rounded-lg font-bold text-sm hover:bg-gray-800 transition-all">SIMPAN PERUBAHAN</button>
      </form>
    </div>
  );
}