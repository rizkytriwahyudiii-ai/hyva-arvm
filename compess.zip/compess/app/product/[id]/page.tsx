'use client';

import Link from 'next/link';
import { Share2, ShoppingBag } from 'lucide-react';
import toast from 'react-hot-toast';
import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import { supabase } from '@/lib/supabaseClient';
import { useCartStore } from '@/lib/store';
import ProductCard from '@/components/ProductCard';

const StarRating = ({ count }: { count: number }) => (
  <div className="text-yellow-600 text-xs">
    {"★".repeat(count) + "☆".repeat(5 - count)}
  </div>
);

export default function ProductDetailPage() {
  const params = useParams();
  const { addToCart } = useCartStore();
  
  const [product, setProduct] = useState<any>(null);
  const [relatedProducts, setRelatedProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadData() {
      if (!params?.id) return;
      try {
        setLoading(true);
        
        // Fetch Product
        const { data: prodData } = await supabase
          .from('products')
          .select('*')
          .eq('id', Number(params.id))
          .single();

        if (prodData) {
          setProduct(prodData);
          
          // Fetch Related (Contoh: berdasarkan kategori yang sama)
          const { data: relData } = await supabase
            .from('products')
            .select('*')
            .eq('category', prodData.category)
            .neq('id', prodData.id)
            .limit(4);
          
          setRelatedProducts(relData || []);
        }
      } catch (error) {
        console.error("Error loading product:", error);
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, [params]);

  const handleAddToCart = () => {
    addToCart(product);
    toast.success(`${product.name} ditambahkan ke keranjang`);
  };

  const handleShare = async () => {
    await navigator.clipboard.writeText(window.location.href);
    toast.success('Link berhasil disalin');
  };

  if (loading) return <div className="p-20 text-center">Loading...</div>;
  if (!product) return <div className="p-20 text-center">Produk tidak ditemukan.</div>;

  return (
    <section className="max-w-7xl mx-auto px-5 md:px-8 pt-8 md:pt-12 pb-12 md:pb-20">
  
  {/* Breadcrumb - Dibuat lebih tipis mengikuti referensi */}
  <div className="mb-8 text-[10px] uppercase tracking-[0.25em] text-stone-400">
    <Link href="/" className="hover:text-black transition-colors">Home</Link>
    <span className="mx-3 text-stone-300">/</span>
    <span className="text-black font-medium">{product.name}</span>
  </div>

  {/* Main Grid */}
  <div className="grid lg:grid-cols-[1.1fr_2fr] gap-12 lg:gap-10 items-start">
    
    {/* IMAGE SECTION - Dibuat lebih clean sesuai image_78837e.png */}
    <div className="relative border border-stone-100 rounded-[2rem] overflow-hidden flex items-center justify-center w-full h-[500px] lg:h-[700px] bg-white">
      <img
        src={`${process.env.NEXT_PUBLIC_STORAGE_URL}${product.image_filename}`}
        alt={product.name}
        className="w-full h-full object-contain p-12 transition-transform duration-700 hover:scale-105"
      />
    </div>

    {/* INFO SECTION */}
    <div className="flex flex-col space-y-8">
      
      {/* Header */}
      <div className="space-y-2">
        <span className="text-[10px] font-semibold uppercase tracking-[0.4em] text-stone-400">
          {product.brand || 'HYVA ARVM'}
        </span>
        <h1 className="text-4xl md:text-5xl font-light text-stone-900 leading-tight">
          {product.name}
        </h1>
        <p className="text-1xl font-light text-stone-700">
          Rp {product.price?.toLocaleString('id-ID')}
        </p>
      </div>

      {/* Badges - Disesuaikan agar lebih rapi */}
      <div className="flex flex-wrap gap-6 ">
        <span className="px-4 py-1.5 text-[9px] uppercase tracking-[0.2em] bg-green-50 text-green-700 border border-green-200">Ready Stock</span>
        <span className="px-4 py-1.5 text-[9px] uppercase tracking-[0.2em] border border-stone-200 text-stone-600">Eau De Parfum</span>
        <span className="px-4 py-1.5 text-[9px] uppercase tracking-[0.2em] border border-stone-200 text-stone-600">50ml</span>
      </div>

      {/* Description */}
      <div className="space-y-3">
        <h3 className="text-[9px] font-bold uppercase tracking-[0.3em] text-stone-400">Description</h3>
        <p className="text-sm text-stone-600 leading-relaxed max-w-lg">
          {product.description}
        </p>
      </div>

      {/* Longevity */}
      <div className="space-y-3">
        <div className="flex justify-between items-center text-[9px] uppercase tracking-[0.3em] text-stone-400">
          <span>Longevity</span>
          <span className="text-stone-700">{product.longevity || 85}%</span>
        </div>
        <div className="h-1 bg-stone-100 rounded-full overflow-hidden">
          <div className="h-full bg-stone-800 transition-all duration-1000" style={{ width: `${product.longevity || 85}%` }} />
        </div>
      </div>

      {/* Fragrance Notes */}
      <div className="space-y-4 pt-4 border-t border-stone-100">
        <h3 className="text-[9px] font-bold uppercase tracking-[0.3em] text-stone-400 mb-2">Fragrance Notes</h3>
        <div className="space-y-4">
          {[
            { label: 'Top', val: product.top_note, stars: 5 },
            { label: 'Heart', val: product.heart_note, stars: 4 },
            { label: 'Base', val: product.base_note, stars: 3 },
          ].map((item) => (
            <div key={item.label} className="grid grid-cols-[60px_1fr_auto] items-center gap-4">
              <span className="text-[9px] uppercase tracking-widest text-stone-400">{item.label}</span>
              <span className="text-sm font-medium text-stone-700">{item.val}</span>
              <StarRating count={item.stars} />
            </div>
          ))}
        </div>
      </div>

      {/* Buttons */}
      <div className="flex flex-col gap-3 pt-4">
        <button onClick={handleAddToCart} className="w-full h-[56px] bg-black text-white text-[10px] uppercase tracking-[0.3em] font-medium hover:bg-stone-800 transition-all flex items-center justify-center gap-2">
          <ShoppingBag size={14} /> Add To Cart
        </button>
        {product.shopee_link && (
          <a href={product.shopee_link} target="_blank" rel="noopener noreferrer" className="w-full h-[56px] border border-stone-200 text-stone-600 text-[10px] uppercase tracking-[0.3em] font-medium hover:border-black hover:text-black transition-all flex items-center justify-center">
            Buy on Shopee
          </a>
        )}
        <button onClick={handleShare} className="w-full h-[56px] border border-stone-100 text-stone-400 text-[10px] uppercase tracking-[0.3em] hover:text-black hover:border-stone-200 transition-all flex items-center justify-center gap-2">
          <Share2 size={14} /> Share
        </button>
      </div>
    </div>
  </div>

      {/* RELATED PRODUCTS */}
      {relatedProducts.length > 0 && (
        <div className="mt-32 border-t border-stone-200 pt-20">
          <div className="text-center mb-14">
            <p className="text-[10px] uppercase tracking-[0.5em] text-gray-400 mb-3">Discover More</p>
            <h2 className="text-3xl md:text-4xl font-light">You May Also Like</h2>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {relatedProducts.map((item) => <ProductCard key={item.id} product={item} />)}
          </div>
        </div>
      )}
    </section>
  );
}