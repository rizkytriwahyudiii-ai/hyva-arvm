export default function HeroSection() {
  const images = ['gambar1.jpg', 'gambar2.jpg', 'gambar3.jpg', 'gambar4.jpg'];
  const delayClasses = ['delay-0', 'delay-4s', 'delay-8s', 'delay-12s'];

  return (
    <section className="relative h-[80vh] w-full flex items-center justify-center bg-black overflow-hidden">
      
      {/* Container Gambar */}
      {images.map((img, index) => (
        <img 
          key={img}
          src={`${process.env.NEXT_PUBLIC_STORAGE_URL}${img}`}
          alt="Hero background"
          /* LOGIKA:
             - Gunakan 'object-[80%_50%]' untuk gambar ke-4 (index 3) pada mobile agar fokus ke kanan.
             - Gunakan 'md:object-center' untuk reset ke posisi tengah pada layar laptop/desktop.
          */
          className={`absolute inset-0 w-full h-full object-cover animate-fade ${delayClasses[index]} opacity-0 ${
            index === 3 
              ? "object-[80%_50%] md:object-center" 
              : "object-center"
          }`}
        />
      ))}
      
      {/* Vignette & Overlay untuk kesan mewah */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_0%,rgba(0,0,0,0.6)_100%)] z-10"></div>
      
      {/* Konten Teks */}
      <div className="relative z-20 text-center px-6 max-w-4xl mx-auto">
        <span className="font-sans text-[10px] md:text-[12px] tracking-[0.4em] text-white/80 uppercase mb-4 block">
          Hyva Arvm Perfume
        </span>
        
        <h1 className="font-serif text-[45px] md:text-8xl text-white tracking-tight leading-[0.85] mb-8">
          ELEVATE YOUR <br className="hidden md:block" /> SCENT
        </h1>
        
        <p className="font-sans text-gray-300 text-[12px] md:text-base font-light mb-10 tracking-[0.1em] max-w-md mx-auto leading-relaxed border-t border-b border-white/20 py-4">
          Inspired by world-class fragrances. Crafted with Extrait de Parfum quality for longevity up to 12 hours.
        </p>

        <a 
          href="#products" 
          className="group relative inline-block px-10 py-4 text-[10px] uppercase tracking-[0.3em] text-white transition-all duration-500 border border-white hover:bg-white hover:text-black"
        >
          Explore Collection
        </a>
      </div>
    </section>
  );
}