import Link from "next/link";

const navLinks = [
  { name: "SHOP", path: "/" },
  { name: "WANITA", path: "/?category=wanita" },
  { name: "PRIA", path: "/?category=pria" },
  { name: "UNISEX", path: "/?category=unisex" }
];

export default function NavLinks({ className, onClick }: { className?: string; onClick?: () => void }) {
  return (
    <>
      {navLinks.map((item) => (
        <Link 
          key={item.name} 
          href={item.path} 
          onClick={onClick} 
          className={`block ${className}`} // Tambahkan 'block' agar lebarnya penuh dan rapi
        >
          {item.name}
        </Link>
      ))}
    </>
  );
}