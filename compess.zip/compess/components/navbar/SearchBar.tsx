'use client';
import { useState } from "react";
import { Search } from "lucide-react";
import { useRouter } from "next/navigation";

export default function SearchBar() {
  const [query, setQuery] = useState("");
  const router = useRouter();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      // Mengarahkan ke halaman hasil pencarian dengan query
      router.push(`/search?q=${encodeURIComponent(query)}`);
    }
  };

  return (
    <form onSubmit={handleSearch} className="flex items-center bg-gray-100/50 rounded-full px-3 py-2 border border-gray-200 hover:border-black hover:bg-white transition-all duration-300">
      <input 
        type="text" 
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder="Cari parfum..." 
        className="bg-transparent text-[11px] font-medium outline-none w-24 sm:w-32 md:w-40 transition-all duration-500 tracking-[0.05em] text-gray-700 placeholder:text-gray-400" 
      />
      <button type="submit">
        <Search size={15} className="text-gray-400 ml-2 cursor-pointer hover:text-black" />
      </button>
    </form>
  );
}