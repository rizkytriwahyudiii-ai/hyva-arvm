export default function TestimonialSection() {
  const testimonials = [
    {
      name: "Aulia",
      text: "Wanginya tahan lama dan mirip parfum original."
    },
    {
      name: "Dian",
      text: "Packaging rapi dan aromanya premium."
    },
    {
      name: "Rizal",
      text: "Harga terjangkau tapi kualitas di atas ekspektasi."
    }
  ];

  return (
    <section className="bg-[#111111] text-white py-24">

      <div className="max-w-6xl mx-auto px-6">

        <div className="text-center mb-16">
          <span className="text-[11px] uppercase tracking-[0.4em] text-white/60">
            Testimonials
          </span>

          <h2 className="text-4xl md:text-5xl font-serif mt-4">
            Loved By Our Customers
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-8">

          {testimonials.map((item, index) => (
            <div
              key={index}
              className="border border-white/10 p-8"
            >
              <p className="text-white/80 leading-7 mb-6">
                "{item.text}"
              </p>

              <span className="text-sm tracking-widest uppercase">
                {item.name}
              </span>
            </div>
          ))}

        </div>

      </div>

    </section>
  );
}