export default function AboutBrand() {
  return (
    <section className="bg-[#F8F5F0] py-24">
      <div className="max-w-5xl mx-auto px-6 text-center">

        <span className="text-[11px] uppercase tracking-[0.4em] text-gray-500">
          Our Story
        </span>

        <h2 className="mt-6 text-4xl md:text-6xl font-serif text-black leading-tight">
          Crafted To Leave
          <br />
          A Lasting Impression
        </h2>

        <div className="w-20 h-[1px] bg-black mx-auto my-8"></div>

        <p className="max-w-2xl mx-auto text-gray-600 leading-8 text-sm md:text-base">
          Hyva Arvm menghadirkan parfum berkualitas tinggi yang
          terinspirasi dari fragrance dunia. Dirancang untuk
          memberikan aroma elegan, tahan lama, dan meningkatkan
          rasa percaya diri dalam setiap aktivitas.
        </p>

      </div>
    </section>
  );
}