export default function Footer() {
  return (
    <footer className="bg-black text-white py-16">

      <div className="max-w-6xl mx-auto px-6">

        <div className="text-center">

          <h3 className="text-2xl font-bold tracking-[0.3em] mb-4">
            HYVA ARVM
          </h3>

          <p className="text-white/60 mb-8">
            Luxury Inspired Fragrance
          </p>

          <div className="flex justify-center gap-8 text-sm uppercase tracking-widest">
            <a href="#">Instagram</a>
            <a href="#">Shopee</a>
            <a href="#">TikTok</a>
          </div>

        </div>

      </div>

    </footer>
  );
}