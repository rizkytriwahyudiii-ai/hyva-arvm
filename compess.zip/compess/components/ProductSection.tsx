import ProductCard from './ProductCard';
import { useRouter } from 'next/navigation';

export default function ProductSection({ title, products, categoryFilter }: { title: string, products: any[], categoryFilter?: string }) {
  const router = useRouter();

  return (
    <section className="mt-8 mb-16 px-4 md:px-6 max-w-6xl mx-auto">
      {/* Header Section */}
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-[12px] md:text-[16px] font-bold uppercase tracking-[0.3em] text-gray-800">
          {title}
        </h2>
        <button 
          onClick={() => router.push(`/search?category=${categoryFilter || ''}`)}
          className="text-[10px] md:text-[11px] uppercase tracking-[0.2em] text-gray-500 hover:text-black transition-colors"
        >
          See All &gt;
        </button>
      </div>

      {/* Grid Produk Responsif:
          - Mobile: 2 kolom (grid-cols-2)
          - Tablet: 3 kolom (md:grid-cols-3)
          - Desktop: 4 kolom (lg:grid-cols-4)
      */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6 lg:gap-8">
        {products.map((product) => (
          <div key={product.id} className="w-full">
            <ProductCard product={product} />
          </div>
        ))}
      </div>
    </section>
  );
}