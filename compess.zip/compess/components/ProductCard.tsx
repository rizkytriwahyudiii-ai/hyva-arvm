'use client';

import React from 'react';
import Link from 'next/link';
import { ShoppingCart } from 'lucide-react';
import { useCartStore } from '@/lib/store';

const ProductCard = ({ product }: { product: any }) => {
  const { addToCart } = useCartStore();

  return (
    <div className="group bg-white flex flex-col h-full border border-gray-100 p-4 transition-all duration-300 hover:shadow-lg hover:-translate-y-1">

      {/* Gambar Produk */}
      <Link href={`/product/${product.id}`}>
        <div className="relative overflow-hidden bg-white aspect-square mb-4 flex items-center justify-center cursor-pointer">
          <img
            src={`${process.env.NEXT_PUBLIC_STORAGE_URL}${product.image_filename}`}
            alt={product.name}
            className="w-full h-full object-contain p-2 transition-transform duration-500 group-hover:scale-105"
          />
        </div>
      </Link>

      {/* Info Produk */}
      <div className="text-center mb-4 flex-grow px-1">

        <p className="text-[9px] uppercase tracking-[0.25em] text-gray-400 mb-2">
          HYVA ARVM
        </p>

        <Link href={`/product/${product.id}`}>
          <h2 className="text-[12px] sm:text-[13px] font-bold text-gray-800 uppercase tracking-wide leading-tight line-clamp-2 hover:text-black transition-colors cursor-pointer">
            {product.name}
          </h2>
        </Link>

        {/* Jika nanti ada notes di database */}
        {product.top_note && (
          <p className="text-[9px] text-gray-500 mt-2 tracking-wide line-clamp-1">
            {product.top_note}
            {product.heart_note && ` • ${product.heart_note}`}
            {product.base_note && ` • ${product.base_note}`}
          </p>
        )}

        <p className="text-[11px] sm:text-[13px] text-gray-900 mt-3 font-semibold">
          Rp {product.price?.toLocaleString('id-ID')}
        </p>

      </div>

      {/* Tombol Keranjang */}
      <button
        onClick={() => addToCart(product)}
        className="w-full bg-black hover:bg-gray-800 text-white py-3 text-[10px] sm:text-[11px] font-bold uppercase tracking-[0.2em] transition-colors flex items-center justify-center gap-2 mt-auto"
      >
        <ShoppingCart size={14} />
        <span>Add To Cart</span>
      </button>

    </div>
  );
};

export default ProductCard;