// DATA SELURUH KATALOG (15 PRODUK SESUAI GAMBAR)
// 1. DATA PRODUK LENGKAP DENGAN LINK SHOPEE
const products = [
    { 
        id: 1, brand: "HYVA ARVM", category: "wanita", name: "Inspired by Romance Wish", price: 48000, img: "ROMANCE-WISH.jpeg", 
        desc: "Aroma floral yang sexy dan fresh. Lembut dan feminin sepanjang hari.", 
        notes: { top: "Floral", heart: "Cucumber", base: "Freesia" },
        karakter: "bunga mentimun segar dingin lembut santai siang hari keringat",
        rating: { top: 5, heart: 3, base: 2, longevity: 80 },
        shopeeLink: "https://shopee.co.id/INSPIRED-BY-ROMANCE-WISH-EXTRAIT-DE-PARFUM-TAHAN-LAMA-i.1543913776.42254653167"
    },
    { 
        id: 2, brand: "HYVA ARVM", category: "wanita", name: "Inspired by Aqua Kiss", price: 48000, img: "AQUA-KISS.jpeg", 
        desc: "Kesegaran aquatic yang sporty. Menetralkan bau badan asam.", 
        notes: { top: "Sea Notes", heart: "Aloe Vera", base: "Daisy" },
        karakter: "laut air pantai citrus dingin segar olahraga panas matahari",
        rating: { top: 5, heart: 4, base: 2, longevity: 60 },
        shopeeLink: "https://shopee.co.id/INSPIRED-BY-AQUA-KISSY-EXTRAIT-DE-PARFUM-TAHAN-LAMA-i.1543913776.41804683639"
    },
    { 
        id: 3, brand: "HYVA ARVM", category: "wanita", name: "Inspired by Scandalous", price: 48000, img: "SCANDALOUS.jpeg", 
        desc: "Aroma manis buah raspberry yang mewah dan elegan.", 
        notes: { top: "Raspberry", heart: "Peony", base: "Praline" },
        karakter: "buah manis elegan pesta mewah malam hari kencan",
        rating: { top: 4, heart: 3, base: 5, longevity: 85 },
        shopeeLink: "https://shopee.co.id/INSPIRED-BY-SCANDALOUS-EXTRAIT-DE-PARFUM-TAHAN-LAMA-i.1543913776.41104657426"
    },
    { 
        id: 4, brand: "HYVA ARVM", category: "wanita", name: "Inspired by Taylor Swift", price: 48000, img: "TYLOR-SWITH.jpeg", 
        desc: "Aroma manis buah yang ceria dan soft.", 
        notes: { top: "Apricot", heart: "Honeysuckle", base: "Musk" },
        karakter: "buah manis ceria lembut kalem sekolah kantor",
        rating: { top: 5, heart: 3, base: 3, longevity: 70 },
        shopeeLink: "https://shopee.co.id/INSPIRED-BY-TAYLOR-SWIFTER-EXTRAIT-DE-PARFUM-TAHAN-LAMA-i.1543913776.26537657509"
    },
    { 
        id: 5, brand: "HYVA ARVM", category: "wanita", name: "Inspired by Pink Chiffon", price: 48000, img: "PINK-CHIFON.jpeg", 
        desc: "Wangi manis lembut, feminin, dan sedikit powdery.", 
        notes: { top: "Red Pear", heart: "Tiare Flower", base: "Chiffon Musk" },
        karakter: "manis bedak lembut cantik ceria feminin",
        rating: { top: 4, heart: 4, base: 3, longevity: 75 },
        shopeeLink: "https://shopee.co.id/INSPIRED-BY-PINKY-CHIFFON-EXTRAIT-DE-PARFUM-TAHAN-LAMA-i.1543913776.40804673592"
    },
    { 
        id: 6, brand: "HYVA ARVM", category: "unisex", name: "Inspired by Baccarat Rouge 540", price: 48000, img: "BACCART.jpeg", 
        desc: "Kemewahan amberwood yang ikonik. Aroma sultan yang bold.", 
        notes: { top: "Saffron", heart: "Amberwood", base: "Fir Resin" },
        karakter: "mewah sultan mahal kayu hangat bold elegan",
        rating: { top: 4, heart: 5, base: 5, longevity: 95 },
        shopeeLink: "https://shopee.co.id/INSPIRED-BY-BACCARAT-EXTRAIT-DE-PARFUM-TAHAN-LAMA-i.1543913776.40704759936"
    },
    { 
        id: 7, brand: "HYVA ARVM", category: "wanita", name: "Inspired by Black Opium", price: 48000, img: "BLACK-OPIUM.jpeg", 
        desc: "Kombinasi kopi dan vanilla yang misterius.", 
        notes: { top: "Coffee", heart: "Jasmine", base: "Vanilla" },
        karakter: "kopi manis elegan malam hari pesta menggoda",
        rating: { top: 4, heart: 3, base: 5, longevity: 90 },
        shopeeLink: "https://shopee.co.id/INSPIRED-BY-BLACKIUM-EXTRAIT-DE-PARFUM-TAHAN-LAMA-i.1543913776.40862503577"
    },
    { 
        id: 8, brand: "HYVA ARVM", category: "wanita", name: "Inspired by Vanilla Mango", price: 48000, img: "VANILA-MANGO.jpeg", 
        desc: "Perpaduan segar mangga tropis dan manis vanilla.", 
        notes: { top: "Mango", heart: "Peach", base: "Vanilla" },
        karakter: "mangga buah tropis segar manis siang hari",
        rating: { top: 5, heart: 3, base: 4, longevity: 80 },
        shopeeLink: "https://shopee.co.id/INSPIRED-BY-VANILLA-MANGO-EXTRAIT-DE-PARFUM-TAHAN-LAMA-i.1543913776.27487662635"
    },
    { 
        id: 9, brand: "HYVA ARVM", category: "wanita", name: "Inspired by Wild Vanilla", price: 48000, img: "WILD-VANILA.jpeg", 
        desc: "Aroma vanilla murni yang hangat dan klasik.", 
        notes: { top: "Vanilla Bean", heart: "Sugar", base: "White Musk" },
        karakter: "vanilla manis hangat kalem klasik nyaman",
        rating: { top: 3, heart: 3, base: 5, longevity: 85 },
        shopeeLink: "https://shopee.co.id/INSPIRED-BY-WILD-VANILLA-EXTRAIT-DE-PARFUM-TAHAN-LAMA-i.1543913776.43854764929"
    },
    { 
        id: 10, brand: "HYVA ARVM", category: "pria", name: "Inspired by 212 VIP Man", price: 48000, img: "212-VIP-MAN.jpeg", 
        desc: "Aroma maskulin yang enerjik dan eksklusif.", 
        notes: { top: "Lime", heart: "Ginger", base: "Leather" },
        karakter: "pria maskulin berani segar jahe sukses modern",
        rating: { top: 4, heart: 4, base: 4, longevity: 80 },
        shopeeLink: "https://shopee.co.id/INSPIRED-BY-212-VIP-MAN-EXTRAIT-DE-PARFUM-TAHAN-LAMA-i.1543913776.29387657892"
    },
    { 
        id: 11, brand: "HYVA ARVM", category: "pria", name: "Inspired by Dunhill Blue", price: 48000, img: "DUNHIL-BLUE.jpeg", 
        desc: "Kesegaran jeruk dan laut clean.", 
        notes: { top: "Lychee", heart: "Rosewood", base: "Amber" },
        karakter: "jeruk leci kamu segar dingin maskulin kerja",
        rating: { top: 5, heart: 3, base: 3, longevity: 80 },
        shopeeLink: "https://shopee.co.id/INSPIRED-BY-BLUE-DUNHILL-EXTRAIT-DE-PARFUM-TAHAN-LAMA-i.1543913776.42104769461"
    },
    { 
        id: 12, brand: "HYVA ARVM", category: "pria", name: "Inspired by Lacoste Sport", price: 48000, img: "LACOSTE-SPORT.jpeg", 
        desc: "Aroma sangat fresh. Terbaik untuk olahraga.", 
        notes: { top: "Grapefruit", heart: "Juniper", base: "Cedar" },
        karakter: "sporty segar jeruk olahraga keringat bersih",
        rating: { top: 5, heart: 4, base: 2, longevity: 70 },
        shopeeLink: "https://shopee.co.id/PARFUM-LCST-SPORT-EXTRAIT-DE-PARFUM-TAHAN-LAMA-HYVA-ARVM-PERFUME-i.1543913776.25296156538"
    },
    { 
        id: 13, brand: "HYVA ARVM", category: "pria", name: "Inspired by One Million Lucky", price: 48000, img: "ONE-MILION-LUCKY.jpeg", 
        desc: "Wangi woodsy yang manis dan unik.", 
        notes: { top: "Plum", heart: "Hazelnut", base: "Cedar" },
        karakter: "kayu manis unik memikat beruntung kacang",
        rating: { top: 4, heart: 5, base: 4, longevity: 85 },
        shopeeLink: "https://shopee.co.id/INSPIRED-BY-ONE-BILLION-LUCKY-EXTRAIT-DE-PARFUM-TAHAN-LAMA-i.1543913776.40254768927"
    },
    { 
        id: 14, brand: "HYVA ARVM", category: "unisex", name: "Inspired by YSL Libre", price: 48000, img: "YSL-LIBRE.jpeg", 
        desc: "Kebebasan dalam aroma lavender mewah.", 
        notes: { top: "Lavender", heart: "Orange Blossom", base: "Vanilla" },
        karakter: "lavender bunga mewah unisex bebas berkelas",
        rating: { top: 4, heart: 4, base: 4, longevity: 90 },
        shopeeLink: "https://shopee.co.id/hyva.arvm" // Default ke toko karena link spesifik belum ada
    },
    { 
        id: 15, brand: "HYVA ARVM", category: "unisex", name: "PROMO BUNDLING 3 BOTOL", price: 140000, img: "bandling.WEBP", 
        desc: "Bebas pilih 3 varian apa saja.", 
        notes: { top: "Mix", heart: "Mix", base: "Mix" },
        karakter: "promo paket hemat pilihan banyak",
        rating: { top: 5, heart: 5, base: 5, longevity: 100 },
        shopeeLink: "https://shopee.co.id/PROMO-HYVA-ARVM-PERFUME-BUNDLING-3-BOTOL-PARFUM-30ML-EXTRAIT-DE-PARFUM-i.1543913776.41504785585"
    }
];

// 2. FUNGSI RENDER BINTANG
function renderStars(count) {
    let stars = "";
    for (let i = 0; i < 5; i++) {
        stars += i < count ? "★" : "☆";
    }
    return stars;
}

// 3. MENAMPILKAN PRODUK KE GRID
function displayProducts(items) {
    const list = document.getElementById('product-list');
    if(!list) return;
    list.innerHTML = "";
    
    items.forEach(product => {
        const item = document.createElement('div');
        item.className = 'product-card';
        item.innerHTML = `
            <div onclick="openDetail(${product.id})" style="cursor:pointer">
                <img src="${product.img}" alt="${product.name}">
                <p class="brand">${product.brand}</p>
                <h3>${product.name}</h3>
                <p class="price">Rp ${product.price.toLocaleString()}</p>
            </div>
            <button class="btn-add" onclick="addToCart(${product.id})">Add To Cart</button>
        `;
        list.appendChild(item);
    });
}

// MODAL DETAIL (VERSI PERBAIKAN SEJAJAR)
function openDetail(id) {
    // 1. Mencari data produk berdasarkan ID
    const p = products.find(prod => prod.id === id);
    if (!p) return;

    // 2. Mengisi data dasar ke dalam elemen HTML modal
    document.getElementById('detail-img').src = p.img;
    document.getElementById('detail-brand').innerText = p.brand;
    document.getElementById('detail-name').innerText = p.name;
    document.getElementById('detail-price').innerText = "Rp " + p.price.toLocaleString();
    document.getElementById('detail-desc').innerText = p.desc;

    // 3. Mengisi Fragrance Notes (Teks Aroma Saja)
    // Kita isi teksnya saja ke ID note- agar tidak double dengan bintang
    document.getElementById('note-top').innerText = p.notes.top;
    document.getElementById('note-heart').innerText = p.notes.heart;
    document.getElementById('note-base').innerText = p.notes.base;

    // 4. Mengisi Rating Bintang ke Wadah Terpisah
    // Ini akan mengisi bintang ke elemen span yang sudah kita beri ID stars-
    document.getElementById('stars-top').innerHTML = renderStars(p.rating.top);
    document.getElementById('stars-heart').innerHTML = renderStars(p.rating.heart);
    document.getElementById('stars-base').innerHTML = renderStars(p.rating.base);

    // 5. Animasi Bar Longevity
    const bar = document.getElementById('bar-fill');
    if (bar) {
        bar.style.width = "0%"; // Reset dulu
        setTimeout(() => {
            bar.style.width = p.rating.longevity + "%";
        }, 100);
    }

    // 6. Menghubungkan tombol Add to Cart
    document.getElementById('add-to-bag-btn').onclick = function() {
        addToCart(p.id);
        closeDetail(); 
    };

    // 7. Tampilkan Modal
    document.getElementById('product-detail-modal').style.display = "block";
}

// FUNGSI UNTUK MENUTUP MODAL DETAIL
function closeDetail() {
    const modal = document.getElementById('product-detail-modal');
    if (modal) {
        modal.style.display = "none";
        // Opsional: Membersihkan isi modal agar saat dibuka lagi tidak ada data lama yang 'berkedip'
        console.log("Modal berhasil ditutup.");
    } else {
        console.error("Elemen dengan ID 'product-detail-modal' tidak ditemukan!");
    }
}

// Menutup modal jika user klik di area hitam (di luar kotak putih)
window.onclick = function(event) {
    const modal = document.getElementById('product-detail-modal');
    if (event.target == modal) {
        closeDetail();
    }
}

// 1. FUNGSI UTAMA UNTUK MENAMPILKAN PRODUK (Versi Update Ikon)
function displayProducts(filteredItems = products) {
    const list = document.getElementById('product-list');
    if (!list) return;
    
    list.innerHTML = ""; // Kosongkan daftar sebelum mengisi yang baru
    
    filteredItems.forEach(product => {
        const item = document.createElement('div');
        item.className = 'product-card';
        
        // Template kartu produk yang diperbarui
        item.innerHTML = `
            <div onclick="openDetail(${product.id})" style="cursor:pointer">
                <img src="${product.img}" alt="${product.name}">
                <p class="brand">${product.brand}</p>
                <h3>${product.name}</h3>
                <p class="price">Rp ${product.price.toLocaleString()}</p>
            </div>
            <button class="btn-add" onclick="addToCart(${product.id})">
                <!-- Menggunakan Ikon Belanja Modern (Font Awesome) -->
                <i class="fas fa-shopping-cart" style="margin-right: 8px;"></i> 
                Add To Cart
            </button>
        `;
        list.appendChild(item);
    });
}

// 2. FUNGSI PENCARIAN AROMA (Menghubungkan Input HTML ke Logika JS)
function filterAroma() {
    // Ambil teks dari input search
    const query = document.getElementById('aromaSearch').value.toLowerCase();
    
    // Filter produk berdasarkan nama, deskripsi, atau karakter aroma
    const filtered = products.filter(p => {
        return p.name.toLowerCase().includes(query) || 
               p.desc.toLowerCase().includes(query) || 
               p.karakter.toLowerCase().includes(query);
    });
    
    // Tampilkan hasil yang sudah difilter
    displayProducts(filtered);
}

// 3. INISIALISASI SAAT HALAMAN DIBUKA
document.addEventListener('DOMContentLoaded', () => {
    displayProducts(products); // Tampilkan semua produk di awal
});

// FILTER KATEGORI
function filterProducts(category) {
    const filtered = category === 'all' ? products : products.filter(p => p.category === category);
    displayProducts(filtered);
    window.scrollTo({ top: 1300, behavior: 'smooth' });
}

// 1. DEFINISI KERANJANG (Letakkan di bagian paling atas script.js)
// Mengambil data dari localStorage, jika tidak ada maka gunakan array kosong []
let cart = JSON.parse(localStorage.getItem('hyva_cart')) || [];

// 1. Fungsi untuk menyimpan setiap perubahan ke LocalStorage
function saveCartToStorage() {
    localStorage.setItem('hyva_cart', JSON.stringify(cart));
}

// 2. FUNGSI UNTUK MENAMBAH BARANG KE KERANJANG
function addToCart(id) {
    const product = products.find(p => p.id === id);
    
    if (product) {
        // Masukkan produk ke dalam array (Hanya satu kali)
        cart.push(product);
        
        // Simpan ke storage agar permanen
        saveCartToStorage();
        
        // Perbarui semua tampilan keranjang
        updateCartUI();
        
        console.log("Berhasil ditambah:", product.name);
    }
}

// 3. FUNGSI UNTUK MEMPERBARUI TAMPILAN KERANJANG
function updateCartUI() {
    // A. Update Angka di Ikon Keranjang (Navbar)
    const cartCount = document.getElementById('cart-count');
    if (cartCount) {
        cartCount.innerText = cart.length;
    }

    // B. Update Daftar Barang di dalam Modal Keranjang
    const container = document.getElementById('cart-items');
    if (container) {
        // Menggunakan ikon tempat sampah dan class 'btn-remove' yang sudah kita buat di CSS
        container.innerHTML = cart.map((item, index) => `
            <div class="cart-item-row" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; border-bottom: 1px solid #eee; padding-bottom: 5px;">
                <div>
                    <p style="margin: 0; font-weight: bold;">${item.name}</p>
                    <p style="margin: 0; color: #666;">Rp ${item.price.toLocaleString()}</p>
                </div>
                <button onclick="removeFromCart(${index})" class="btn-remove" title="Hapus Barang">
                    <i class="fas fa-trash-alt"></i> HAPUS
                </button>
            </div>
        `).join('');
    }

    // C. Update Total Harga
    const totalLabel = document.getElementById('total-price');
    if (totalLabel) {
        const total = cart.reduce((sum, item) => sum + item.price, 0);
        totalLabel.innerText = "Rp " + total.toLocaleString();
    }
}

// 4. FUNGSI HAPUS BARANG (PERMANEN)
function removeFromCart(index) {
    // Hapus item dari array berdasarkan index
    cart.splice(index, 1);
    
    // Simpan perubahan ke LocalStorage
    saveCartToStorage();
    
    // Perbarui tampilan agar item yang dihapus langsung hilang
    updateCartUI();
}

// 5. MEMUAT DATA SAAT HALAMAN DIBUKA
// Pastikan data lama muncul kembali saat user buka web
function loadCartOnStart() {
    const savedData = localStorage.getItem('hyva_cart');
    if (savedData) {
        cart = JSON.parse(savedData);
        updateCartUI();
    }
}

// Jalankan fungsi muat data saat website siap
window.onload = loadCartOnStart;


// CHECKOUT WA
function checkoutWA() {
    if (cart.length === 0) return alert("Keranjang kosong!");
    let msg = "Halo Hyva Arvm, saya mau pesan:%0A";
    cart.forEach(i => msg += `- ${i.name}%0A`);
    let total = cart.reduce((s, i) => s + i.price, 0);
    msg += `%0ATotal: Rp ${total.toLocaleString()}`;
    window.open(`https://wa.me/628123456789?text=${msg}`, '_blank');
}

function checkoutShopee() {
    window.open("https://shopee.co.id/hyva.arvm", "_blank");
}

function toggleCart() {
    const cartModal = document.getElementById('cart-modal');
    if (!cartModal) return;

    // Logika menutup/membuka modal
    if (cartModal.style.display === "block") {
        cartModal.style.display = "none";
        document.body.style.overflow = 'auto'; // Mengaktifkan klik produk kembali
    } else {
        cartModal.style.display = "block";
        document.body.style.overflow = 'hidden'; // Mencegah scroll saat cart buka
    }
}   

function checkoutShopee() {
    if (cart.length === 0) {
        alert("Keranjangmu masih kosong, silakan pilih parfum favoritmu dulu!");
        return;
    }

    // Jika user hanya memilih 1 produk dan produk itu punya link Shopee
    if (cart.length === 1 && cart[0].shopeeLink) {
        window.open(cart[0].shopeeLink, "_blank");
    } else {
        // Jika banyak produk, arahkan ke halaman utama toko Hyva Arvm di Shopee
        // Sesuaikan link di bawah dengan link toko utama Anda
        window.open("https://shopee.co.id/hyva.arvm", "_blank");
        alert("Kamu memilih beberapa parfum. Silakan cari produknya di toko Shopee kami ya!");
    }
}

function checkoutOtomatis() {
    if (cart.length === 0) {
        alert("Keranjang belanjaanmu masih kosong, Rizky!");
        return;
    }

    // Menghitung total belanja
    const total = cart.reduce((sum, item) => sum + item.price, 0);
    
    // Menampilkan total ke dalam modal
    const totalLabel = document.getElementById('qris-total');
    if (totalLabel) {
        totalLabel.innerText = "Total Tagihan: Rp " + total.toLocaleString();
    }
    
    // Munculkan modal
    document.getElementById('qris-modal').style.display = "block";
}

function tutupQRIS() {
    document.getElementById('qris-modal').style.display = "none";
}

function hubungiAdmin() {
    // Arahkan ke WA untuk kirim bukti
    const total = cart.reduce((sum, item) => sum + item.price, 0);
    const pesan = encodeURIComponent(`Halo Admin Hyva Arvm, saya sudah melakukan pembayaran QRIS sebesar Rp ${total.toLocaleString()}. Berikut bukti bayarnya.`);
    window.open(`https://wa.me/628123456789?text=${pesan}`, "_blank"); // Ganti dengan nomor WA-mu
}


// Menutup modal jika area luar kotak diklik
window.onclick = function(event) {
    const modal = document.getElementById('login-modal');
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

// Mengatur tampilan tab Login/Daftar
function showAuthTab(type) {
    const loginForm = document.getElementById('form-login');
    const daftarForm = document.getElementById('form-daftar');
    const tabL = document.getElementById('tab-login');
    const tabD = document.getElementById('tab-daftar');
    const footer = document.getElementById('auth-footer');

    if (type === 'login') {
        loginForm.style.display = 'block';
        daftarForm.style.display = 'none';
        tabL.style.color = '#a68b5c'; tabL.style.borderBottom = '2px solid #a68b5c';
        tabD.style.color = '#777'; tabD.style.borderBottom = 'none';
        footer.innerHTML = 'Baru di Hyva Arvm? <a href="#" onclick="showAuthTab(\'daftar\')" style="color: #a68b5c;">Daftar</a>';
    } else {
        loginForm.style.display = 'none';
        daftarForm.style.display = 'block';
        tabD.style.color = '#a68b5c'; tabD.style.borderBottom = '2px solid #a68b5c';
        tabL.style.color = '#777'; tabL.style.borderBottom = 'none';
        footer.innerHTML = 'Sudah punya akun? <a href="#" onclick="showAuthTab(\'login\')" style="color: #a68b5c;">Login</a>';
    }
}

function closeAuthModal() {
    document.getElementById('auth-modal').style.display = 'none';
}

function openAuthModal() {
    document.getElementById('auth-modal').style.display = 'block';
}

// Simulasi Proses Auth & Penyimpanan Keranjang
function handleUserAuth(event, mode) {
    event.preventDefault();
    // Simulasikan login berhasil
    const userEmail = event.target.querySelector('input[type="email"]').value;
    
    // Simpan status login di localStorage
    localStorage.setItem('isLoggedIn', 'true');
    localStorage.setItem('userEmail', userEmail);
    
    alert(`${mode === 'login' ? 'Login' : 'Pendaftaran'} Berhasil! Keranjang Anda sekarang tersimpan.`);
    closeAuthModal();
    updateUIForLoggedInUser();
}

function loginWithGoogle() {
    alert("Mengarahkan ke Google Login...");
    // Di sini nantinya kita integrasikan dengan Google Identity Services API
}

function updateUIForLoggedInUser() {
    const loginTrigger = document.querySelector('.login-trigger i');
    if(localStorage.getItem('isLoggedIn') === 'true') {
        loginTrigger.style.color = '#a68b5c'; // Berubah warna jika sudah login
    }
}

// 1. Fungsi untuk menangani login dan pendaftaran
function handleUserAuth(event, type) {
    event.preventDefault(); // Mencegah halaman reload

    let userName = "";
    
    if (type === 'daftar') {
        // Ambil nama dari input pertama di form daftar
        userName = event.target.querySelector('input[type="text"]').value;
        alert("Pendaftaran Berhasil! Halo " + userName);
    } else {
        // Untuk simulasi login, kita gunakan email sebagai nama sementara 
        // atau kamu bisa set nama default
        const email = event.target.querySelector('input[type="email"]').value;
        userName = email.split('@')[0]; // Ambil bagian depan email
        alert("Login Berhasil!");
    }

    // Simpan nama ke localStorage agar tidak hilang saat refresh
    localStorage.setItem('loggedInUser', userName);
    
    // Perbarui tampilan navbar
    updateNavbarUser();
    
    // Tutup modal
    closeAuthModal();
}

// 2. Fungsi untuk mengubah teks di Navbar
function updateNavbarUser() {
    const userTextElement = document.getElementById('user-auth-text');
    const savedName = localStorage.getItem('loggedInUser');

    if (savedName && userTextElement) {
        // Ubah teks "Login / Daftar" menjadi nama user
        userTextElement.innerText = savedName;
        
        // Opsional: Matikan fungsi buka modal jika sudah login
        // Atau arahkan ke halaman profile
        document.querySelector('.auth-trigger').onclick = function() {
            if(confirm("Logout?")) {
                localStorage.removeItem('loggedInUser');
                location.reload();
            }
        };
    }
}

// 3. Jalankan pengecekan setiap kali halaman dimuat
window.onload = function() {
    updateNavbarUser();
    // Panggil fungsi slideshow atau init produkmu yang lain di sini
};

function handleLogout() {
    // 1. Hapus data login
    localStorage.removeItem('loggedInUser');
    
    // 2. Hapus data keranjang agar kembali ke 0
    localStorage.removeItem('hyva_cart');
    
    // 3. Arahkan kembali ke halaman utama
    window.location.href = 'index.html'; 
}

// Update fungsi trigger di navbar
document.querySelector('.auth-trigger').onclick = function() {
    const userTextElement = document.getElementById('user-auth-text');
    if (userTextElement.innerText !== "LOGIN / DAFTAR") {
        if(confirm("Apakah Anda ingin logout? Keranjang belanja akan dikosongkan.")) {
            handleLogout();
        }
    } else {
        openAuthModal();
    }
};

// JALANKAN OTOMATIS
document.addEventListener('DOMContentLoaded', () => {
    displayProducts();
});